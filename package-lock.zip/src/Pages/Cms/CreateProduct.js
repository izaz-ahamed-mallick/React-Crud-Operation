import React from "react";

const CreateProduct = () => {
    return <div>CreateProduct</div>;
};

export default CreateProduct;
