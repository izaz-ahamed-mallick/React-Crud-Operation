import React from "react";

const Update = () => {
    return <div>Update</div>;
};

export default Update;
