import React from "react";

const PrivateRouteComponent = ({ children }) => {
    return <div className="w-full h-screen">{children}</div>;
};

export default PrivateRouteComponent;
