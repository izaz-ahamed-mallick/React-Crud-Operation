import React from "react";

const Home = () => {
    return <div className="w-full h-screen">Home</div>;
};

export default Home;
