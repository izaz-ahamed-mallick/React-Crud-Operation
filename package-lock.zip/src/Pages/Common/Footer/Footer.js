import React from "react";

const Footer = () => {
    return <div className="w-full h-20 shadow-lg bg-red-100">Footer</div>;
};

export default Footer;
