import React from "react";
import { Link } from "react-router-dom";

const Header = () => {
    return (
        <div className="w-full h-[80px] shadow-lg bg-gray-300 px-6">
            <div className="h-full flex  items-center justify-between">
                <div>
                    <h1 className="text-4xl font-semibold">
                        <span className="text-orange-600">X</span>
                        <span className="text-white">Y</span>
                        <span className="text-green-700">Z</span>
                    </h1>
                </div>
                <div>
                    <button className="bg-green-700 text-white w-[100px] h-[40px] text-lg font-semibold rounded-2xl">
                        <Link to={"/login"}>Login</Link>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Header;
